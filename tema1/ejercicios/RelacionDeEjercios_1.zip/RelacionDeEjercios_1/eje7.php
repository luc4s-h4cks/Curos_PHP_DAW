<?php


$res= 0;
for($i=1;$i<=100;$i++){
    $res+= $i*$i;
}
echo $res;