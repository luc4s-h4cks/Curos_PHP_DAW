<?php

$numeros = array(3,1,4,1,5,9);

sort($numeros);

print_r($numeros);

echo"<br><br><br>";

rsort($numeros);


print_r($numeros);
