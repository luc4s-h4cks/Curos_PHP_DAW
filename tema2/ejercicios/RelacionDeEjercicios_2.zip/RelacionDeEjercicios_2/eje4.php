<?php

$animales = array("gato", "perro", "elefante", "jirafa");

echo count($animales)."<br>";

array_push($animales, "loro", "pez");

echo count($animales);
