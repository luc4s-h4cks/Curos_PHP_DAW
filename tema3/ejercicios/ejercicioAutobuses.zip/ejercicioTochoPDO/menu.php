<?php

?>
<h1>MENU</h1>
<a href="insertarAuto.php">Añadir autobus</a><br>
<a href="insertarViaje.php">Añadir viaje</a><br>
<a href="modificar-borrar.php">Modificar/Borrar viaje</a><br>
<a href="reservar.php">Reservar</a><br>

