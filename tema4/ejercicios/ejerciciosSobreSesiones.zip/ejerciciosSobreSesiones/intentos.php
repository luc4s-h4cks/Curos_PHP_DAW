<h1>Has agotado tods tus intentos</h1>
<h2>Cierrar el navegador e intentalo de nuevo</h2>
