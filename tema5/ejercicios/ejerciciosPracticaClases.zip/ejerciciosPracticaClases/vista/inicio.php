<?php

?>

<button><a href="cerrar.php">Salir</a></button><br>
<a href="nueva.php">Nueva tarea</a><br>
<a href="modificar.php">Actualizar tarea</a><br>
